# globalstudy
